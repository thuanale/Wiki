#!/bin/sh

ps auxw | grep Server_Manager_ | grep -v grep > /dev/null

if [ $? != 0 ]
then
echo java -version
java -version
        java -jar /home/shared/bin/as400-monitor-server-linux/Server_Manager_v1.4.2.jar 3389 3390 &> /dev/null
fi
