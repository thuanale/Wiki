
import glob
import csv
import pathlib
import sys
import time
import paramiko
from pathlib import Path
from paramiko import SSHClient
from scp import SCPClient
from xlsxwriter.workbook import Workbook
from pathlib import Path
import pysftp as sftp
import pysftp as sftp
import paramiko
import os
import subprocess
import pysftp
import os, os.path
import win32com.client
from win32com.client import Dispatch
import getpass
#print('Current working directory path:',os.getcwd())
user = getpass.getpass("LBN_Username exp:bq.tran :")
passwd = getpass.getpass("Password for " + user + ":")

print ("Got", user, passwd)
x=' '
local=r"D:\qsec\Newcsv"
remote = "/home/lbn/"+user+"/qsec/newfolder/"
local1=r"D:\qsec\Oldcsv"
remote1 = "/home/lbn/"+user+"/qsec/oldfolder/"
local2=r"D:\qsec\report.txt"
remote2 = "/home/lbn/"+user+"/qsec/report.txt"

def compare():
        fileslst = os.listdir(local)
        fileslst1 = os.listdir(local1)
        ssh = paramiko.SSHClient()
        ssh.load_host_keys(os.path.expanduser(os.path.join("~", ".ssh", "known_hosts")))
        ssh.connect(hostname='lsinlrebpmn801.dfs.obs.sg.linkbynet.com', username=user, password=passwd)
        sftp = ssh.open_sftp()
        print("clearing ~/qsec/newfolder/")
        stdin, stdout, stderr = ssh.exec_command("rm -r /home/lbn/"+user+"/qsec/newfolder/*")
        print(stdout.read())
        print("clearing ~/qsec/oldfolder/")
        stdin1, stdout1, stderr1 = ssh.exec_command("rm -r /home/lbn/"+user+"/qsec/oldfolder/*")
        print(stdout1.read())
        for file in fileslst :
            #print(local + "\\" + file)
            print("sending" + x+ file+x+"to"+x+remote)
            sftp.put(local+"\\"+ file, remote+file)

        for old in fileslst1:
            #print(local1 + "\\" + old)
            print("sending" + x +old+x+"to"+x+remote1)
            sftp.put(local1 + "\\" + old, remote1+old)
        print("running compare script")
        stdin2, stdout2, stderr2 = ssh.exec_command("/home/lbn/"+user+"/qsec/qsec.sh")
        for line in stdout2.readlines():
            print(line)
        print("getting report named report.txt which will be located at"+x+local2)
        sftp.get(remote2, local2)
        sftp.close()
        ssh.close()

def excel():

        excel = Dispatch("Excel.Application")
        excel.Visible = True
        workbook = excel.Workbooks.Open(r"D:\qsec\Qsecofr.xlsm")
        workbook.Application.Run("Module4.runallmacros")
        excel.Quit()
excel()
compare()
input()








